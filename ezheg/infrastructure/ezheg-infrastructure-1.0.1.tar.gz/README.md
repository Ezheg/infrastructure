# Ansible Collection - ezheg.infrastructure
Created with cooperation Andrey M.

Features include:
1. Creates IAM Group "DevOps" and 2 users within
2. Create 5 t2.micro Instances with ami-074cce78125f09d61 image on a board
3. Provide complite installation of Wordpress engine to Ubutu servers


Thank You for choosing our collections.

Copyright © 2021 EvolveCyber juniors Team.



Documentation for the collection.